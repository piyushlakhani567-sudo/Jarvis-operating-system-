package com.jarvis.os;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.widget.*;
import androidx.biometric.BiometricPrompt;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import java.util.*;

public class MainActivity extends Activity {
    JarvisView hud; SpeechRecognizer speech; TextToSpeech tts; Locale language=Locale.ENGLISH;
    String[] langs={"English","Hindi","Gujarati","Spanish","French","German","Arabic","Tamil","Telugu","Bengali"};
    Locale[] locales={Locale.ENGLISH,new Locale("hi","IN"),new Locale("gu","IN"),new Locale("es"),Locale.FRENCH,Locale.GERMAN,new Locale("ar"),new Locale("ta"),new Locale("te"),new Locale("bn")};
    @Override public void onCreate(Bundle b){super.onCreate(b); requestFullscreen(); hud=new JarvisView(this); setContentView(hud); initTts(); new Handler().postDelayed(()->authenticate(),350);}
    void requestFullscreen(){Window w=getWindow(); if(android.os.Build.VERSION.SDK_INT>=30) w.setDecorFitsSystemWindows(false); else w.setFlags(1024,1024);}
    void initTts(){tts=new TextToSpeech(this,status->{if(status==TextToSpeech.SUCCESS){tts.setLanguage(language);}},"com.google.android.tts");}
    void authenticate(){
        hud.mode="FACE SCAN"; hud.invalidate();
        BiometricPrompt.AuthenticationCallback cb=new BiometricPrompt.AuthenticationCallback(){
            @Override public void onAuthenticationSucceeded(BiometricPrompt.AuthenticationResult r){hud.mode="ONLINE"; hud.invalidate(); speak("Identity verified. Welcome. I am JARVIS.");}
            @Override public void onAuthenticationFailed(){hud.scan="TRY AGAIN"; hud.invalidate();}
            @Override public void onAuthenticationError(int e, CharSequence s){hud.mode="ONLINE"; hud.invalidate();}
        };
        BiometricPrompt bp=new BiometricPrompt(this,ContextCompat.getMainExecutor(this),cb);
        BiometricPrompt.PromptInfo info=new BiometricPrompt.PromptInfo.Builder().setTitle("JARVIS identity scan").setSubtitle("Use face, fingerprint, or your device credential").setNegativeButtonText("Use JARVIS without scan").build();
        try{bp.authenticate(info);}catch(Exception e){hud.mode="ONLINE";hud.invalidate();}
    }
    void speak(String s){if(tts!=null) tts.speak(s,TextToSpeech.QUEUE_FLUSH,null,"jarvis");}
    void listen(){
        if(ActivityCompat.checkSelfPermission(this,Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED){ActivityCompat.requestPermissions(this,new String[]{Manifest.permission.RECORD_AUDIO},10);return;}
        if(!SpeechRecognizer.isRecognitionAvailable(this)){speak("Speech recognition is not available on this device.");return;}
        if(speech!=null)speech.destroy(); speech=SpeechRecognizer.createSpeechRecognizer(this);
        speech.setRecognitionListener(new android.speech.RecognitionListener(){
            public void onReadyForSpeech(Bundle b){hud.mode="LISTENING";hud.invalidate();}
            public void onBeginningOfSpeech(){} public void onRmsChanged(float r){} public void onBufferReceived(byte[] b){} public void onEndOfSpeech(){}
            public void onError(int e){hud.mode="ONLINE";hud.invalidate();}
            public void onResults(Bundle b){ArrayList<String> x=b.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION); String q=x==null?"":x.get(0); hud.last=q; command(q);}
            public void onPartialResults(Bundle b){} public void onEvent(int a,Bundle b){}
        });
        Intent i=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE,language.toLanguageTag()); i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); speech.startListening(i);
    }
    void command(String q){hud.mode="THINKING";hud.invalidate(); String s=q.toLowerCase(language);
        if(s.contains("language")||s.contains("भाषा")||s.contains("bhasha")){showLanguages();return;}
        if(s.contains("youtube")){openPackage("com.google.android.youtube");return;}
        if(s.contains("whatsapp")){openPackage("com.whatsapp");return;}
        if(s.contains("instagram")){openPackage("com.instagram.android");return;}
        if(s.contains("settings")){startActivity(new Intent(android.provider.Settings.ACTION_SETTINGS));finish();return;}
        if(s.contains("battery")){BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE); int p=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY); speak("Battery is at "+p+" percent."); hud.mode="ONLINE";hud.invalidate();return;}
        if(s.contains("time")){speak(new java.text.SimpleDateFormat("h:mm a",language).format(new Date()));hud.mode="ONLINE";hud.invalidate();return;}
        speak("Command received: "+q+". I can open apps, change language, read system status, and run supported JARVIS actions.");hud.mode="ONLINE";hud.invalidate();
    }
    void openPackage(String pkg){try{Intent i=getPackageManager().getLaunchIntentForPackage(pkg); if(i!=null)startActivity(i); else speak("That application is not installed.");}catch(Exception e){speak("I could not open that application.");} hud.mode="ONLINE";hud.invalidate();}
    void showLanguages(){new AlertDialog.Builder(this).setTitle("JARVIS VOICE LANGUAGE").setSingleChoiceItems(langs,Arrays.asList(locales).indexOf(language),(d,w)->{language=locales[w]; if(tts!=null)tts.setLanguage(language); speak("Language changed to "+langs[w]); d.dismiss(); hud.invalidate();}).setNegativeButton("Cancel",null).show();}
    void showApps(){LinearLayout box=new LinearLayout(this);box.setOrientation(LinearLayout.VERTICAL);box.setPadding(35,20,35,20); ScrollView sc=new ScrollView(this); LinearLayout list=new LinearLayout(this);list.setOrientation(LinearLayout.VERTICAL);
        Intent main=new Intent(Intent.ACTION_MAIN,null);main.addCategory(Intent.CATEGORY_LAUNCHER); List<android.content.pm.ResolveInfo> apps=getPackageManager().queryIntentActivities(main,0); Collections.sort(apps,(a,b)->a.loadLabel(getPackageManager()).toString().compareToIgnoreCase(b.loadLabel(getPackageManager()).toString()));
        for(android.content.pm.ResolveInfo r:apps){Button x=new Button(this);x.setText(r.loadLabel(getPackageManager()).toString());x.setOnClickListener(v->{startActivity(r.activityInfo!=null?new Intent().setClassName(r.activityInfo.packageName,r.activityInfo.name):new Intent());});list.addView(x);} sc.addView(list);box.addView(sc);new AlertDialog.Builder(this).setTitle("JARVIS APP COMMAND CENTER").setView(box).setNegativeButton("Close",null).show();}
    class JarvisView extends View{
        android.graphics.Paint p=new android.graphics.Paint(1); String mode="BOOTING",scan="100%",last="Say: Hey JARVIS"; float pulse=0;
        JarvisView(Context c){super(c);p.setTypeface(android.graphics.Typeface.create("sans",0));setBackgroundColor(android.graphics.Color.rgb(2,7,11));}
        void txt(android.graphics.Canvas c,String s,float x,float y,float size){p.setTextSize(size);p.setColor(android.graphics.Color.rgb(220,250,255));c.drawText(s,x,y,p);}
        void line(android.graphics.Canvas c,float x1,float y1,float x2,float y2){p.setColor(android.graphics.Color.rgb(0,150,190));p.setStrokeWidth(2);c.drawLine(x1,y1,x2,y2,p);}
        @Override protected void onDraw(android.graphics.Canvas c){super.onDraw(c); int w=getWidth(),h=getHeight(); pulse=(pulse+2)%360;
            p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(2);p.setColor(android.graphics.Color.rgb(0,190,230));
            c.drawRect(18,18,w-18,h-18,p); for(int i=0;i<3;i++)c.drawCircle(w/2,h/2-80,115+i*22+(float)Math.sin(Math.toRadians(pulse+i*30))*5,p);
            p.setStyle(android.graphics.Paint.Style.FILL); txt(c,"JARVIS OS",28,62,28); txt(c,"PERSONAL AI COMMAND SYSTEM",30,86,12); txt(c,new java.text.SimpleDateFormat("h:mm a",language).format(new Date()),w-150,58,18);
            txt(c,mode,w/2-45,190,18); txt(c,"IDENTITY / VOICE / COMMAND",w/2-105,214,11); txt(c,"JARVIS",w/2-43,h/2-85,30);
            txt(c,"SYSTEM STATUS",28,300,15); txt(c,"CPU     NORMAL",28,325,12);txt(c,"RAM     NORMAL",28,348,12);txt(c,"BATTERY  "+battery()+"%",28,371,12);
            txt(c,"LAST COMMAND",w-190,300,15); txt(c,last.length()>25?last.substring(0,25):last,w-190,325,11); txt(c,"LANGUAGE: "+language.getDisplayLanguage(language).toUpperCase(),w-190,350,11);
            p.setStyle(android.graphics.Paint.Style.FILL); button(c,25,h-145,170,h-90,"🎙  SPEAK"); button(c,185,h-145,325,h-90,"▦  APPS"); button(c,340,h-145,475,h-90,"◉  SECURITY"); button(c,25,h-78,225,h-35,"🌐  LANGUAGE"); button(c,240,h-78,475,h-35,"☾  REST MODE");
            if(mode.equals("FACE SCAN")){p.setStyle(android.graphics.Paint.Style.STROKE);p.setStrokeWidth(3);p.setColor(android.graphics.Color.rgb(0,240,255));c.drawRect(w/2-125,250,w/2+125,430,p);txt(c,"FACIAL / BIOMETRIC SCAN",w/2-105,465,13);txt(c,"ALIGN YOUR FACE",w/2-62,486,11);}
            if(mode.equals("LISTENING")){txt(c,"● LISTENING…",w/2-65,235,14);}
            postInvalidateDelayed(40);
        }
        void button(android.graphics.Canvas c,int l,int t,int r,int b,String s){p.setStyle(android.graphics.Paint.Style.STROKE);p.setColor(android.graphics.Color.rgb(0,120,160));p.setStrokeWidth(2);c.drawRoundRect(l,t,r,b,18,18,p);p.setStyle(android.graphics.Paint.Style.FILL);txt(c,s,l+12,t+35,13);}
        int battery(){BatteryManager bm=(BatteryManager)getSystemService(BATTERY_SERVICE);return bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY);}
        @Override public boolean onTouchEvent(android.view.MotionEvent e){if(e.getAction()!=1)return true;float x=e.getX(),y=e.getY();int h=getHeight(); if(y>h-160&&y<h-85){if(x<180)listen(); else if(x<335)showApps(); else showSecurity();} else if(y>h-90){if(x<230)showLanguages(); else showRest();} return true;}
    }
    void showSecurity(){new AlertDialog.Builder(this).setTitle("JARVIS SECURITY MODE").setMessage("Biometric identity scan is available at startup. For stronger app protection, enable JARVIS as your launcher and use Android's supported security/accessibility features. JARVIS cannot bypass another app's own lock or Android security.").setPositiveButton("Run scan",(d,w)->authenticate()).setNegativeButton("Close",null).show();}
    void showRest(){new AlertDialog.Builder(this).setTitle("REST MODE").setMessage("Minimal JARVIS mode: clock, battery and wake controls. Voice wake requires microphone permission and supported Android services.").setPositiveButton("Activate",(d,w)->{hud.mode="REST MODE";hud.invalidate();speak("Rest mode activated.");}).setNegativeButton("Close",null).show();}
    @Override protected void onDestroy(){if(speech!=null)speech.destroy();if(tts!=null)tts.shutdown();super.onDestroy();}
}
