# JARVIS OS V2

A phone-first JARVIS-style Android launcher/shell. It is an app that can act as the device's Home/launcher; it is **not a replacement for Android itself**.

## Included
- Futuristic JARVIS HUD
- Startup biometric/face-capable authentication using Android BiometricPrompt
- Multilingual speech recognition and text-to-speech language selection
- Voice commands for supported actions and opening common apps
- App command center
- Battery/system status
- Security and Rest Mode screens
- HOME launcher intent so JARVIS can be selected as the default launcher

## Build with GitHub Actions
1. Upload this project to a GitHub repository.
2. Push the included `.github/workflows/build.yml`.
3. Open **Actions → Build JARVIS OS V2 → Run workflow**.
4. Download the `JARVIS-OS-APK` artifact and install the APK.

## Important Android limits
JARVIS OS is a launcher/shell, not a replacement Android kernel/OS. Face authentication uses the device's supported biometric system. App-locking other apps, remote-device control, and deeper system controls require explicit Android permissions, pairing, APIs, or device-owner/managed-device setup; the app does not bypass Android or another app's security.
